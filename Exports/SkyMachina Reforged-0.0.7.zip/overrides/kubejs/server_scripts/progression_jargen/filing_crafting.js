console.info('Makin them filings usefull for once...')

ServerEvents.recipes(event => {
    event.shaped(
        Item.of('skymachina:copper_chunk', 1),
        [
            'fff',
            'fgf',
            'fff'
        ],
        {
            f: 'skymachina:copper_filings',
            g: 'minecraft:gravel'
        }
    )
    event.shaped(
        Item.of('skymachina:iron_chunk', 1),
        [
            'fff',
            'fgf',
            'fff'
        ],
        {
            f: 'skymachina:iron_filings',
            g: 'minecraft:gravel'
        }
    )
    event.shaped(
        Item.of('skymachina:tin_chunk', 1),
        [
            'fff',
            'fgf',
            'fff'
        ],
        {
            f: 'skymachina:tin_filings',
            g: 'minecraft:gravel'
        }
    )
    event.shaped(
        Item.of('skymachina:gold_chunk', 1),
        [
            'fff',
            'fgf',
            'fff'
        ],
        {
            f: 'skymachina:gold_filings',
            g: 'minecraft:gravel'
        }
    )
    event.shaped(
        Item.of('skymachina:zinc_chunk', 1),
        [
            'fff',
            'fgf',
            'fff'
        ],
        {
            f: 'skymachina:zinc_filings',
            g: 'minecraft:gravel'
        }
    )
    event.shaped(
        Item.of('skymachina:lead_chunk', 1),
        [
            'fff',
            'fgf',
            'fff'
        ],
        {
            f: 'skymachina:lead_filings',
            g: 'minecraft:gravel'
        }
    )
    event.shaped(
        Item.of('skymachina:osmium_chunk', 1),
        [
            'fff',
            'fgf',
            'fff'
        ],
        {
            f: 'skymachina:osmium_filings',
            g: 'minecraft:gravel'
        }
    )
    event.shaped(
        Item.of('skymachina:uranium_chunk', 1),
        [
            'fff',
            'fgf',
            'fff'
        ],
        {
            f: 'skymachina:uranium_filings',
            g: 'minecraft:gravel'
        }
    )
    event.shaped(
        Item.of('skymachina:silver_chunk', 1),
        [
            'fff',
            'fgf',
            'fff'
        ],
        {
            f: 'skymachina:silver_filings',
            g: 'minecraft:gravel'
        }
    )
    event.shaped(
        Item.of('skymachina:nickel_chunk', 1),
        [
            'fff',
            'fgf',
            'fff'
        ],
        {
            f: 'skymachina:nickel_filings',
            g: 'minecraft:gravel'
        }
    )
    event.shaped(
        Item.of('skymachina:bauxite_chunk', 1),
        [
            'fff',
            'fgf',
            'fff'
        ],
        {
            f: 'skymachina:bauxite_filings',
            g: 'minecraft:gravel'
        }
    )
})




