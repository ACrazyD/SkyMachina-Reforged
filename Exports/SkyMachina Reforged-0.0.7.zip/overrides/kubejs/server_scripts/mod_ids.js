let MC = (id) => 'minecraft:'+id
let SM = (id) => 'skymachina:'+id
let CC = (id) => 'computercraft:'+id
let APO = (id) => 'apotheosis:'+id
let CP = (id) => 'compressium:'+id