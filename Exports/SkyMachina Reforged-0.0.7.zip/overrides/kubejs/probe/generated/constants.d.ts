/// <reference path="./globals.d.ts" />
declare const HOUR: 3600000;
declare const global: {"jeiRuntime": Internal.og2RNlZylYF};
declare const IngredientHelper: Internal.IngredientPlatformHelperImpl;
declare const Painter: Internal.Painter;
declare const MINUTE: 60000;
declare const Client: Internal.Minecraft;
declare const console: Internal.ConsoleJS;
declare const Java: Internal.JavaWrapper;
declare const FTBQuests: Internal.FTBQuestsKubeJSWrapper;
declare const SECOND: 1000;
