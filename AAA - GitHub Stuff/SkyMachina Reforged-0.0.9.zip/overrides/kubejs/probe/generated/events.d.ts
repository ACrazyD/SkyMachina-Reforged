/// <reference path="./globals.d.ts" />
/// <reference path="./registries.d.ts" />
declare const ServerEvents: {
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
recipes(handler: (event: Internal.RecipesEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
specialRecipeSerializers(handler: (event: Internal.SpecialRecipeSerializerManager) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
compostableRecipes(handler: (event: Internal.CompostableRecipesEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
entityLootTables(handler: (event: Internal.EntityLootEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
tick(handler: (event: Internal.ServerEventJS) => void):void,
    /**
     * This event is cancellable.
     * 
     * This event fires on **server**.
    */
command(extra: string, handler: (event: Internal.CommandEventJS) => void):void,
command(handler: (event: Internal.CommandEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
blockLootTables(handler: (event: Internal.BlockLootEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
tags(extra: string, handler: (event: Internal.TagEventJS<any>) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
loaded(handler: (event: Internal.ServerEventJS) => void):void,
    /**
     * This event is cancellable.
     * 
     * This event fires on **server**.
    */
customCommand(extra: Special.EntityType, handler: (event: Internal.CustomCommandEventJS) => void):void,
customCommand(handler: (event: Internal.CustomCommandEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
giftLootTables(handler: (event: Internal.GiftLootEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
commandRegistry(handler: (event: Internal.CommandRegistryEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
afterRecipes(handler: (event: Internal.AfterRecipesLoadedEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
chestLootTables(handler: (event: Internal.ChestLootEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
unloaded(handler: (event: Internal.ServerEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
recipeTypeRegistry(handler: (event: Internal.RecipeTypeRegistryEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
lowPriorityData(handler: (event: Internal.DataPackEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
fishingLootTables(handler: (event: Internal.FishingLootEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
genericLootTables(handler: (event: Internal.GenericLootEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
highPriorityData(handler: (event: Internal.DataPackEventJS) => void):void,
};
declare const IEEvents: {
    /**
     * This event is cancellable.
     * 
     * This event fires on **startup**.
    */
multiblockForm(extra: Special.EntityType, handler: (event: Internal.MultiblockFormEventJS) => void):void,
multiblockForm(handler: (event: Internal.MultiblockFormEventJS) => void):void,
};
declare const WorldgenEvents: {
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **startup**.
    */
add(handler: (event: Internal.AddWorldgenEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **startup**.
    */
remove(handler: (event: Internal.RemoveWorldgenEventJS) => void):void,
};
declare const NetworkEvents: {
    /**
     * This event is cancellable.
     * 
     * This event fires on **client**.
    */
fromServer(extra: Special.EntityType, handler: (event: Internal.NetworkEventJS) => void):void,
    /**
     * This event is cancellable.
     * 
     * This event fires on **server**.
    */
fromClient(extra: Special.EntityType, handler: (event: Internal.NetworkEventJS) => void):void,
};
declare const JEIEvents: {
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **client**.
    */
hideItems(handler: (event: Internal.HideJEIEventJS<any>) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **client**.
    */
addFluids(handler: (event: Internal.AddJEIEventJS<any>) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **client**.
    */
hideFluids(handler: (event: Internal.HideJEIEventJS<any>) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **client**.
    */
removeRecipes(handler: (event: Internal.RemoveJEIRecipesEvent) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **client**.
    */
removeCategories(handler: (event: Internal.RemoveJEICategoriesEvent) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **client**.
    */
information(handler: (event: Internal.InformationJEIEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **client**.
    */
hideCustom(handler: (event: Internal.HideCustomJEIEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **client**.
    */
subtypes(handler: (event: Internal.JEISubtypesEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **client**.
    */
addItems(handler: (event: Internal.AddJEIEventJS<any>) => void):void,
};
declare const PlayerEvents: {
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
decorateChat(handler: (event: Internal.PlayerChatDecorateEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
chestOpened(handler: (event: Internal.ChestEventJS) => void):void,
    /**
     * This event is cancellable.
     * 
     * This event fires on **server**.
    */
advancement(extra: ResourceLocation, handler: (event: Internal.PlayerAdvancementEventJS) => void):void,
advancement(handler: (event: Internal.PlayerAdvancementEventJS) => void):void,
    /**
     * This event is cancellable.
     * 
     * This event fires on **server**.
    */
chat(handler: (event: Internal.PlayerChatDecorateEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
chestClosed(handler: (event: Internal.ChestEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
loggedIn(handler: (event: Internal.SimplePlayerEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
loggedOut(handler: (event: Internal.SimplePlayerEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
inventoryClosed(handler: (event: Internal.InventoryEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
inventoryChanged(extra: Special.Item, handler: (event: Internal.InventoryChangedEventJS) => void):void,
inventoryChanged(handler: (event: Internal.InventoryChangedEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
inventoryOpened(handler: (event: Internal.InventoryEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
tick(handler: (event: Internal.SimplePlayerEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
respawned(handler: (event: Internal.PlayerRespawnedEventJS) => void):void,
};
declare const Ponder: {
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **client**.
    */
registry(handler: (event: Internal.PonderRegistryEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **client**.
    */
tags(handler: (event: Internal.PonderItemTagEventJS) => void):void,
};
declare const ItemEvents: {
    /**
     * This event is cancellable.
     * 
     * This event fires on **server**.
    */
rightClicked(extra: Special.Item, handler: (event: Internal.ItemClickedEventJS) => void):void,
rightClicked(handler: (event: Internal.ItemClickedEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **client**.
    */
clientLeftClicked(extra: Special.Item, handler: (event: Internal.ItemClickedEventJS) => void):void,
clientLeftClicked(handler: (event: Internal.ItemClickedEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
crafted(extra: Special.Item, handler: (event: Internal.ItemCraftedEventJS) => void):void,
crafted(handler: (event: Internal.ItemCraftedEventJS) => void):void,
    /**
     * This event is cancellable.
     * 
     * This event fires on **server**.
    */
dropped(extra: Special.Item, handler: (event: Internal.ItemDroppedEventJS) => void):void,
dropped(handler: (event: Internal.ItemDroppedEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **client**.
    */
tooltip(handler: (event: Internal.ItemTooltipEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **startup**.
    */
modelProperties(handler: (event: Internal.ItemModelPropertiesEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
firstRightClicked(extra: Special.Item, handler: (event: Internal.ItemClickedEventJS) => void):void,
firstRightClicked(handler: (event: Internal.ItemClickedEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **client**.
    */
clientRightClicked(extra: Special.Item, handler: (event: Internal.ItemClickedEventJS) => void):void,
clientRightClicked(handler: (event: Internal.ItemClickedEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **startup**.
    */
modification(handler: (event: Internal.ItemModificationEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
pickedUp(extra: Special.Item, handler: (event: Internal.ItemPickedUpEventJS) => void):void,
pickedUp(handler: (event: Internal.ItemPickedUpEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
destroyed(extra: Special.EntityType, handler: (event: Internal.ItemDestroyedEventJS) => void):void,
destroyed(handler: (event: Internal.ItemDestroyedEventJS) => void):void,
    /**
     * This event is cancellable.
     * 
     * This event fires on **server**.
    */
entityInteracted(extra: Special.Item, handler: (event: Internal.ItemEntityInteractedEventJS) => void):void,
entityInteracted(handler: (event: Internal.ItemEntityInteractedEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **startup**.
    */
toolTierRegistry(handler: (event: Internal.ItemToolTierRegistryEventJS) => void):void,
    /**
     * This event is cancellable.
     * 
     * This event fires on **server**.
    */
foodEaten(extra: Special.Item, handler: (event: Internal.FoodEatenEventJS) => void):void,
foodEaten(handler: (event: Internal.FoodEatenEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
firstLeftClicked(extra: Special.Item, handler: (event: Internal.ItemClickedEventJS) => void):void,
firstLeftClicked(handler: (event: Internal.ItemClickedEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **startup**.
    */
armorTierRegistry(handler: (event: Internal.ItemArmorTierRegistryEventJS) => void):void,
    /**
     * This event is cancellable.
     * 
     * This event fires on **server**.
    */
canPickUp(extra: Special.Item, handler: (event: Internal.ItemPickedUpEventJS) => void):void,
canPickUp(handler: (event: Internal.ItemPickedUpEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
smelted(extra: Special.Item, handler: (event: Internal.ItemSmeltedEventJS) => void):void,
smelted(handler: (event: Internal.ItemSmeltedEventJS) => void):void,
};
declare const LevelEvents: {
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
loaded(extra: ResourceLocation, handler: (event: Internal.SimpleLevelEventJS) => void):void,
loaded(handler: (event: Internal.SimpleLevelEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
unloaded(extra: ResourceLocation, handler: (event: Internal.SimpleLevelEventJS) => void):void,
unloaded(handler: (event: Internal.SimpleLevelEventJS) => void):void,
    /**
     * This event is cancellable.
     * 
     * This event fires on **server**.
    */
beforeExplosion(handler: (event: Internal.ExplosionEventJS$Before) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
tick(extra: ResourceLocation, handler: (event: Internal.SimpleLevelEventJS) => void):void,
tick(handler: (event: Internal.SimpleLevelEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
afterExplosion(handler: (event: Internal.ExplosionEventJS$After) => void):void,
};
declare const EntityEvents: {
    /**
     * This event is cancellable.
     * 
     * This event fires on **server**.
    */
spawned(extra: Special.EntityType, handler: (event: Internal.EntitySpawnedEventJS) => void):void,
spawned(handler: (event: Internal.EntitySpawnedEventJS) => void):void,
    /**
     * This event is cancellable.
     * 
     * This event fires on **server**.
    */
drops(extra: Special.EntityType, handler: (event: Internal.LivingEntityDropsEventJS) => void):void,
drops(handler: (event: Internal.LivingEntityDropsEventJS) => void):void,
    /**
     * This event is cancellable.
     * 
     * This event fires on **server**.
    */
checkSpawn(extra: Special.EntityType, handler: (event: Internal.CheckLivingEntitySpawnEventJS) => void):void,
checkSpawn(handler: (event: Internal.CheckLivingEntitySpawnEventJS) => void):void,
    /**
     * This event is cancellable.
     * 
     * This event fires on **server**.
    */
death(extra: Special.EntityType, handler: (event: Internal.LivingEntityDeathEventJS) => void):void,
death(handler: (event: Internal.LivingEntityDeathEventJS) => void):void,
    /**
     * This event is cancellable.
     * 
     * This event fires on **server**.
    */
hurt(extra: Special.EntityType, handler: (event: Internal.LivingEntityHurtEventJS) => void):void,
hurt(handler: (event: Internal.LivingEntityHurtEventJS) => void):void,
};
declare const ClientEvents: {
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **client**.
    */
init(handler: (event: Internal.ClientEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **client**.
    */
rightDebugInfo(handler: (event: Internal.DebugInfoEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **client**.
    */
leftDebugInfo(handler: (event: Internal.DebugInfoEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **client**.
    */
loggedIn(handler: (event: Internal.ClientEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **client**.
    */
loggedOut(handler: (event: Internal.ClientEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **client**.
    */
paintScreen(handler: (event: Internal.PaintScreenEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **client**.
    */
tick(handler: (event: Internal.ClientEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **client**.
    */
painterUpdated(handler: (event: Internal.ClientEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **client**.
    */
highPriorityAssets(handler: (event: Internal.GenerateClientAssetsEventJS) => void):void,
};
declare const CreateEvents: {
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **startup**.
    */
boilerHeatHandler(handler: (event: Internal.BoilerHeaterHandlerEvent) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **startup**.
    */
pipeFluidEffect(handler: (event: Internal.SpecialFluidHandlerEvent) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **startup**.
    */
spoutHandler(handler: (event: Internal.SpecialSpoutHandlerEvent) => void):void,
};
declare const StartupEvents: {
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **startup**.
    */
init(handler: (event: Internal.StartupEventJS) => void):void,
registry(type: "minecraft.sound_event", handler: (event: Registry.SoundEvent) => void):void,
registry(type: "sound_event", handler: (event: Registry.SoundEvent) => void):void,
registry(type: "minecraft.fluid", handler: (event: Registry.Fluid) => void):void,
registry(type: "fluid", handler: (event: Registry.Fluid) => void):void,
registry(type: "minecraft.block", handler: (event: Registry.Block) => void):void,
registry(type: "block", handler: (event: Registry.Block) => void):void,
registry(type: "minecraft.item", handler: (event: Registry.Item) => void):void,
registry(type: "item", handler: (event: Registry.Item) => void):void,
registry(type: "minecraft.enchantment", handler: (event: Registry.Enchantment) => void):void,
registry(type: "enchantment", handler: (event: Registry.Enchantment) => void):void,
registry(type: "minecraft.mob_effect", handler: (event: Registry.MobEffect) => void):void,
registry(type: "mob_effect", handler: (event: Registry.MobEffect) => void):void,
registry(type: "minecraft.entity_type", handler: (event: Registry.EntityType) => void):void,
registry(type: "entity_type", handler: (event: Registry.EntityType) => void):void,
registry(type: "minecraft.block_entity_type", handler: (event: Registry.BlockEntityType) => void):void,
registry(type: "block_entity_type", handler: (event: Registry.BlockEntityType) => void):void,
registry(type: "minecraft.potion", handler: (event: Registry.Potion) => void):void,
registry(type: "potion", handler: (event: Registry.Potion) => void):void,
registry(type: "minecraft.particle_type", handler: (event: Registry.ParticleType) => void):void,
registry(type: "particle_type", handler: (event: Registry.ParticleType) => void):void,
registry(type: "minecraft.painting_variant", handler: (event: Registry.PaintingVariant) => void):void,
registry(type: "painting_variant", handler: (event: Registry.PaintingVariant) => void):void,
registry(type: "minecraft.custom_stat", handler: (event: Registry.CustomStat) => void):void,
registry(type: "custom_stat", handler: (event: Registry.CustomStat) => void):void,
registry(type: "minecraft.point_of_interest_type", handler: (event: Registry.PointOfInterestType) => void):void,
registry(type: "point_of_interest_type", handler: (event: Registry.PointOfInterestType) => void):void,
registry(type: "minecraft.villager_type", handler: (event: Registry.VillagerType) => void):void,
registry(type: "villager_type", handler: (event: Registry.VillagerType) => void):void,
registry(type: "minecraft.villager_profession", handler: (event: Registry.VillagerProfession) => void):void,
registry(type: "villager_profession", handler: (event: Registry.VillagerProfession) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **startup**.
    */
postInit(handler: (event: Internal.StartupEventJS) => void):void,
};
declare const BlockEvents: {
    /**
     * This event is cancellable.
     * 
     * This event fires on **server**.
    */
broken(extra: Special.Block, handler: (event: Internal.BlockBrokenEventJS) => void):void,
broken(handler: (event: Internal.BlockBrokenEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
detectorPowered(extra: Special.Block, handler: (event: Internal.DetectorBlockEventJS) => void):void,
detectorPowered(handler: (event: Internal.DetectorBlockEventJS) => void):void,
    /**
     * This event is cancellable.
     * 
     * This event fires on **server**.
    */
farmlandTrampled(extra: Special.Block, handler: (event: Internal.FarmlandTrampledEventJS) => void):void,
farmlandTrampled(handler: (event: Internal.FarmlandTrampledEventJS) => void):void,
    /**
     * This event is cancellable.
     * 
     * This event fires on **server**.
    */
placed(extra: Special.Block, handler: (event: Internal.BlockPlacedEventJS) => void):void,
placed(handler: (event: Internal.BlockPlacedEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
detectorUnpowered(extra: Special.Block, handler: (event: Internal.DetectorBlockEventJS) => void):void,
detectorUnpowered(handler: (event: Internal.DetectorBlockEventJS) => void):void,
    /**
     * This event is cancellable.
     * 
     * This event fires on **server**.
    */
leftClicked(extra: Special.Block, handler: (event: Internal.BlockLeftClickedEventJS) => void):void,
leftClicked(handler: (event: Internal.BlockLeftClickedEventJS) => void):void,
    /**
     * This event is cancellable.
     * 
     * This event fires on **server**.
    */
rightClicked(extra: Special.Block, handler: (event: Internal.BlockRightClickedEventJS) => void):void,
rightClicked(handler: (event: Internal.BlockRightClickedEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
detectorChanged(extra: Special.Block, handler: (event: Internal.DetectorBlockEventJS) => void):void,
detectorChanged(handler: (event: Internal.DetectorBlockEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **startup**.
    */
modification(handler: (event: Internal.BlockModificationEventJS) => void):void,
};
declare const REIEvents: {
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **client**.
    */
add(extra: string, handler: (event: Internal.AddREIEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **client**.
    */
hide(extra: string, handler: (event: Internal.HideREIEventJS<any>) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **client**.
    */
information(handler: (event: Internal.InformationREIEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **client**.
    */
removeCategories(handler: (event: Internal.RemoveREICategoryEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **client**.
    */
groupEntries(handler: (event: Internal.GroupREIEntriesEventJS) => void):void,
};
declare const GameStageEvents: {
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
stageAdded(extra: Special.EntityType, handler: (event: Internal.GameStageEventJS) => void):void,
stageAdded(handler: (event: Internal.GameStageEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
stageRemoved(extra: Special.EntityType, handler: (event: Internal.GameStageEventJS) => void):void,
stageRemoved(handler: (event: Internal.GameStageEventJS) => void):void,
};
declare const FTBQuestsEvents: {
    /**
     * This event is cancellable.
     * 
     * This event fires on **server**.
    */
customReward(extra: Special.EntityType, handler: (event: Internal.CustomRewardEventJS) => void):void,
customReward(handler: (event: Internal.CustomRewardEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
started(extra: string, handler: (event: Internal.QuestObjectStartedEventJS) => void):void,
started(handler: (event: Internal.QuestObjectStartedEventJS) => void):void,
    /**
     * This event is **not** cancellable.
     * 
     * This event fires on **server**.
    */
completed(extra: string, handler: (event: Internal.QuestObjectCompletedEventJS) => void):void,
completed(handler: (event: Internal.QuestObjectCompletedEventJS) => void):void,
    /**
     * This event is cancellable.
     * 
     * This event fires on **server**.
    */
customTask(extra: string, handler: (event: Internal.CustomTaskEventJS) => void):void,
customTask(handler: (event: Internal.CustomTaskEventJS) => void):void,
};
