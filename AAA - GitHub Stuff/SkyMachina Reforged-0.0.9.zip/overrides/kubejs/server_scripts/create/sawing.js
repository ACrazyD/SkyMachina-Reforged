ServerEvents.recipes(e => {
    //SawDust
    e.recipes.create.cutting('stick', 'thermal:sawdust')
  })